<?php
    date_default_timezone_set("Asia/Manila");
    $id = $_POST["id"];

    //VAR_DUMP, USE TRIM TO REMOVE THE UNWANTED SPACES INFRON AND BACK
    $fname      = trim($_POST["fname"]);
    $lname      = trim($_POST["lname"]);
    $email      = trim($_POST["email"]);
    $password1  = trim($_POST["password1"]);
    $password2  = trim($_POST["password2"]);
    $mobile_no  = trim($_POST["mobile_no"]);
    $bday       = trim($_POST["bday"]);
    $sex        = trim($_POST["inputSex"]);
    $address    = trim($_POST["address"]);
    $barangay   = trim($_POST["barangay"]);
    $city       = trim($_POST["city"]);
    $province   = trim($_POST["province"]);
    $zipcode    = trim($_POST["zipcode"]);

    //CONNECTION TO THE DATABASE
    include_once("connection.php");

    //CHECKING IF THE INPUT EMAIL IS SAME AS THE EMAIL INSIDE THE DATABASE
    $execQuery    = mysqli_query($con, "SELECT * FROM tbl_users WHERE id = '$id'");
    $fetchEmail   = mysqli_fetch_assoc($execQuery);
    $stored_email = $fetchEmail["email"];
    $numOfRows    = mysqli_num_rows($execQuery);

    if($numOfRows > 1){
        if($stored_email == $email){
            header("Location: index.php?msg=20"); exit;
        }
    } 

        //CHECKING IF THE PASSWORD IS THE SAME WITH THE CONFIRM PASSWORD
        if($password1 == $password2){
            //PASSWORD HASH, FOR DATA PRIVACY
            $encPassword = password_hash($password1, PASSWORD_DEFAULT);
    
            //IF THERE'S NO DUPLICATION IN THE DATABASE AND PASSWORD IS THE SAME WITH CONFIRM PASSWORD, NEXT WILL BE INSERT QUERY
    
            //UPDATE IN TBL_USERS
            $execQuery2 = mysqli_query($con, "UPDATE tbl_users SET first_name = '$fname', last_name = '$lname', email = '$email', password = '$encPassword', mobile_no = '$mobile_no', updated_at = now() WHERE id = '$id'");
            
            $execQuery4 = mysqli_query($con, "UPDATE tbl_address SET user_id = '$id', address = '$address', barangay = '$barangay', city = '$city', province = '$province', zip = '$zipcode' WHERE user_id = '$id'");
    
            //FOR UPLOAD DP
            // $filename1 = "PIC_" . $id . "_" . date("Ymd_His") . "_" . $_FILES["inputDP"]["name"][0];
            // $targetfile1 = "uploads/credentials/" . $filename1;
            // $filetype1 = $_FILES["inputDP"]["type"][0];
    
            // if($filetype1 != ""){
            //     if($filetype1 != "image/jpg" && $filetype1 != "image/png" && $filetype1 != "image/jpeg") {
            //         header("Location: index.php?msg=24"); exit;
            //     }
                
            //     //UPLOAD
            //     if(move_uploaded_file($_FILES["inputDP"]["tmp_name"][0], $targetfile1)){
            //         $updateCredentials1 = mysqli_query($con, "UPDATE tbl_users SET profile_picture = '$filename1' WHERE id = '$id'");
            //         if($updateCredentials1){
            //             header("Location: index.php?msg=25"); exit;
            //         }
            //     } else{
            //         header("Location: index.php?msg=26"); exit;
            //     }
            // }
    
            //FOR UPLOAD CREDENTIALS
            // $filename2 = "PIC_" . $id . "_" . date("Ymd_His") . "_" . $_FILES["inputFile"]["name"][0];
            // $targetfile2 = "uploads/credentials/" . $filename2;
            // $filetype2 = $_FILES["inputFile"]["type"][0];
    
            // // ALLOW CERTAIN FORMATS
            // if($filetype2 != ""){
            //     if($filetype2 != "image/jpg" && $filetype2 != "image/png" && $filetype2 != "image/jpeg") {
            //         header("Location: index.php?msg=24"); exit;
            //     }
                
            //     //UPLOAD
            //     if(move_uploaded_file($_FILES["inputFile"]["tmp_name"][0], $targetfile2)){
            //         $updateCredentials2 = mysqli_query($con, "UPDATE tbl_users SET credentials = '$filename2' WHERE id = '$id'");
            //         if($updateCredentials2){
            //             header("Location: index.php?msg=25"); exit;
            //         }
            //     } else{
            //         header("Location: index.php?msg=26"); exit;
            //     }
            // }
            
            //EXECUTE QUERY CONDITIONS
            if($execQuery2){
                $_SESSION["msg"] = 10;
                header("Location: index.php"); exit;
            } else{
                $_SESSION["msg"] = 7;
                echo "<script> function returnToPreviousPage() { window.history.back(); } returnToPreviousPage(); </script>";
            } 
        } else{
            $_SESSION["msg"] = 8;
            echo "<script> function returnToPreviousPage() { window.history.back(); } returnToPreviousPage(); </script>";
        }
?>