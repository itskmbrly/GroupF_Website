<?php 
    include_once("connection.php"); 
    $services = '';

    if(isset($_SESSION["sess-role"]) && $_SESSION["sess-role"] != ""){
      $sessId = $_SESSION["sess-id"];

      //FETCHING THE USER'S NAME AND ROLE
      $userInfo = mysqli_query($con,  "SELECT * FROM tbl_users WHERE id = '$sessId'");
      $fetchInfo = mysqli_fetch_assoc($userInfo);
      $fname = $fetchInfo["first_name"];
      $lname = $fetchInfo["last_name"];
      $id   = $fetchInfo["id"];

    }
?>
<div class="k-container">
    <!--Banner-->
    <div class="container p-3 my-3 banner text-white">
        <h2>Good Day, <?php echo $fname; ?>!</h2>
        <h3>Welcome to JentleKare.</h3>
        <i>A platform for all your beauty needs.</i>
    </div>
</div>