<?php 
    include_once("connection.php"); 
    $services = '';

    if(isset($_SESSION["sess-role"]) && $_SESSION["sess-role"] != ""){
      $sessId = $_SESSION["sess-id"];

      //FETCHING THE USER'S NAME AND ROLE
      $userInfo = mysqli_query($con,  "SELECT * FROM tbl_users WHERE id = '$sessId'");
      $fetchInfo = mysqli_fetch_assoc($userInfo);
      $fname = $fetchInfo["first_name"];
      $lname = $fetchInfo["last_name"];
      $id   = $fetchInfo["id"];

      //SELECT QUERY - TBL_SERVICES
      $selectQuery  = mysqli_query($con, "SELECT * FROM tbl_services");
      while($row = mysqli_fetch_assoc($selectQuery)){
        $services .= "<option value='" . $row["id"] . "'>" . $row["service_name"] . "</option>";
    }
  } 
?>
<div class="k-container">
    <!--Banner-->
    <div class="container p-3 my-3 banner text-white">
        <h2>Good Day, <?php echo $fname; ?>!</h2>
        <h3>Welcome to JentleKare.</h3>
        <i>A platform for all your beauty needs.</i>
    </div>
    <button type="button" class="btn btn-add-serv" data-toggle="modal" data-target="#myModal">
        Add Service
    </button>
    <!-- The Modal -->
    <div class="modal" id="myModal">
        <div class="modal-dialog">
        <div class="modal-content">
        
            <!-- Modal Header -->
            <div class="modal-header">
            <h4 class="modal-title">Add Service</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            
            <!-- Modal body -->
            <div class="modal-body">
                <form action="handle-kraft-add-service.php" method="POST" class="needs-validation" novalidate>
                    <div class="form-group fg">
                        <select name="inputService"  class="form-control" required >
                            <option value="" disabled selected hidden>Choose a Service</option>
                            <?php echo $services; ?>
                        </select>
                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please fill out this field.</div>
                    </div>
                    <div class="form-group fg">
                        <input type="number" name="price" placeholder="Enter price" class="form-control" min="0" required>
                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please fill out this field.</div>
                    </div>
                    <input type="submit" value="Submit">
                </form>
            </div>
            
            <!-- Modal footer -->
            <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
            
        </div>
        </div>
    </div>
</div>
<script>
    // Disable form submissions if there are invalid fields
    (function() {
    'use strict';
    window.addEventListener('load', function() {
        // Get the forms we want to add validation styles to
        var forms = document.getElementsByClassName('needs-validation');
        // Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function(form) {
        form.addEventListener('submit', function(event) {
            if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
        });
    }, false);
    })();
</script>