<div class="w3-sidebar w3-bar-block w3-card left">
    <center><img src="../images/JentleKare.png" alt="Logo" style="width: 55%"></center>
    <?php
      if(isset($_SESSION["sess-role"]) && $_SESSION["sess-role"] != ""){
        //REMOVE WHEN DONE: you can insert here the profile picture
        //NAME
        if($_SESSION["sess-role"] == 1){
          echo"
            <a href='profile-page-laborer.php?id=$id' class='w3-bar-item w3-button'><i class='fa fa-user-circle'></i> $fname $lname</a>
          ";
        } else{
          echo"
            <a href='profile-page.php?id=$id' class='w3-bar-item w3-button'><i class='fa fa-user-circle'></i> $fname $lname</a>
          ";
        }
        
        //HOME
        if($_SESSION["sess-role"] == 1 || $_SESSION["sess-role"] == 2){
            echo'
                <a href="index.php" class="w3-bar-item w3-button"><i class="fa fa-home"></i> Home</a>
            ';
        }

        //MY APPOINTMENTS && MY FAVORITES
        if($_SESSION["sess-role"] == 2){
          echo"<a href='appointments.php' class='w3-bar-item w3-button'><i class='fa fa-calendar'></i> My Appointments</a>";

          echo"<a href='favorites.php' class='w3-bar-item w3-button'><i class='fa fa-heart'></i> My Favorites</a>";
        }

        if($_SESSION["sess-role"] == 3){
            echo"<a href='list-users.php' class='w3-bar-item w3-button'><i class='fa fa-group'></i> List of Users</a>";
            echo"<a href='index.php' class='w3-bar-item w3-button'><i class='fa fa-cogs'></i> List of Services</a>";
            echo"<a href='create-user.php' class='w3-bar-item w3-button'><i class='fa fa-user-plus'></i> Create User</a>";
            echo"<a href='create-services.php' class='w3-bar-item w3-button'><i class='fa fa-plus-square'></i> Create Services</a>";
        }

        //CHANGE PASSWORD
        echo'
          <a href="change-password.php" class="w3-bar-item w3-button chg-pass"><i class="fa fa-key"></i> Change Password</a>
        ';
        //LOG OUT
        echo'
          <a href="logout.php" class="w3-bar-item w3-button logout-btn"><i class="fa fa-sign-out"></i> Logout</a>
        ';
      } else{
          echo"
            <a href='index.php' class='w3-bar-item w3-button'><i class='fa fa-home'></i> Home</a>
          ";
          echo"
            <a href='sign-up-sign-in.php' class='w3-bar-item w3-button'><i class='fa fa-sign-in'></i> Sign In | Sign Up</a>
          ";
      }
    ?>
</div>